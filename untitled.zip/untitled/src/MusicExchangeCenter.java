import java.util.ArrayList;

public class MusicExchangeCenter {
    ArrayList<User> users;

    public MusicExchangeCenter() {
        users = new ArrayList<>();
        users.clear();
    }
    public ArrayList<User> onlineUsers() {
        ArrayList<User> onlineUsers = new ArrayList<>();
        onlineUsers.clear(); //so there are no null items in the ArrayList
        for (User u: users) {
            if(u.isOnline()) {
                onlineUsers.add(u);
            }
        }
        return onlineUsers;
    }
    public ArrayList<Song> allAvailableSongs() {
        ArrayList<Song> availableSongs = new ArrayList<>();
        availableSongs.clear();
        for (User u: onlineUsers()) {
            for (Song s: u.getSongList()) {
                availableSongs.add(s);
            }
        }
        return availableSongs;
    }

    @Override
    public String toString() {
        return "Music Exchange Center ( "+onlineUsers().size()+ " users on line, "+ allAvailableSongs().size() + " songs available) ";
    }
    public User userWithName(String s) {

    }
}
