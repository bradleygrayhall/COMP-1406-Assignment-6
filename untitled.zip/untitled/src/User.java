import java.util.ArrayList;

public class User {
    private String userName;
    private boolean online;
    private ArrayList<Song> songList;

    public User() { this(""); }
    public User(String u) {
        userName = u;
        online = false;
        songList = new ArrayList<>();
        songList.clear();
    }
    public String getUserName() { return userName; }
    public ArrayList<Song> getSongList() {
        return songList;
    }

    public boolean isOnline() { return online; }
    public String toString() {
        String s = "" + userName + ": " + songList.size() + " songs (";
        if (!online) s += "not ";
        return s + "online)";
    }
    public void addSong(Song s) {
        songList.add(s);
    }
    public int totalSongTime() {
        int songTime = 0;
        for (Song s: songList) {
            songTime += s.getSeconds();
        }
        return songTime;
    }
}
